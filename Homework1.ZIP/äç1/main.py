import pygame
import os
import sys

pygame.init()
SIZE = 50

screen = pygame.display.set_mode((550, 550))
pygame.display.set_caption("Марио")
clock = pygame.time.Clock()

def load_image(name):
    return pygame.image.load(f"data/{name}")

def start_screen():
    intro_text = ["Перемещение героя"]

    fon = pygame.transform.scale(load_image('fon.jpg'), (550, 550))
    screen.blit(fon, (0, 0))
    font = pygame.font.Font(None, 30)
    text_coord = 50
    for line in intro_text:
        string_rendered = font.render(line, 1, pygame.Color(0, 0, 0))
        intro_rect = string_rendered.get_rect()
        text_coord += 10
        intro_rect.top = text_coord
        intro_rect.x = 10
        text_coord += intro_rect.height
        screen.blit(string_rendered, intro_rect)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            elif event.type == pygame.KEYDOWN or event.type == pygame.MOUSEBUTTONDOWN:
                return  # начинаем игру
        pygame.display.flip()
        clock.tick(50)

def load_level(filename):
    # Check if the file exists
    if not os.path.exists(filename):
        print("Файла не найдено")

    # Read the level from the file
    with open(filename, 'r') as mapFile:
        level_map = [line.strip() for line in mapFile]

    # Calculate the maximum width
    max_width = max(map(len, level_map))

    # Pad each line with '.' to make them equal in length
    return list(map(lambda x: x.ljust(max_width, '.'), level_map))

class Tile(pygame.sprite.Sprite):
    def __init__(self, tile_type, pos_x, pos_y):
        super().__init__(tiles_group, all_sprites)
        self.image = tile_images[tile_type]
        self.rect = self.image.get_rect().move(SIZE * pos_x, SIZE * pos_y)

class Player(pygame.sprite.Sprite):
    def __init__(self, pos_x, pos_y):
        super().__init__(player_group, all_sprites)
        self.image = player_image
        self.rect = self.image.get_rect()
        self.rect.x = SIZE * pos_x
        self.rect.y = SIZE * pos_y
        self.pos_x = pos_x
        self.pos_y = pos_y
        self.last_move_time = 0

    def move(self, dx, dy):
        current_time = pygame.time.get_ticks()
        if current_time - self.last_move_time < 200:
            return
        new_x = self.pos_x + dx
        new_y = self.pos_y + dy
        if 0 <= new_x < level_width and 0 <= new_y < level_height:
            if level[new_y][new_x] != '#':
                self.pos_x = new_x
                self.pos_y = new_y
                self.rect.x = SIZE * self.pos_x
                self.rect.y = SIZE * self.pos_y
                self.last_move_time = current_time

def generate_level(level):
    new_player = None
    for y in range(len(level)):
        for x in range(len(level[y])):
            if level[y][x] == '.':
                Tile('empty', x, y)
            elif level[y][x] == '#':
                Tile('wall', x, y)
            elif level[y][x] == '@':
                Tile('empty', x, y)
                new_player = Player(x, y)
    return new_player

tile_images = {
    'wall': load_image('box.png'),
    'empty': load_image('grass.png')
}
player_image = load_image('mar.png')

all_sprites = pygame.sprite.Group()
tiles_group = pygame.sprite.Group()
player_group = pygame.sprite.Group()

# Get the filename from input
filename = input("Введите название: (в формате .txt)")

# Load the level
level = load_level(filename)
level_height = len(level)
level_width = len(level[0])

# Generate the level
player = generate_level(level)

start_screen()

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        player.move(-1, 0)
    if keys[pygame.K_RIGHT]:
        player.move(1, 0)
    if keys[pygame.K_UP]:
        player.move(0, -1)
    if keys[pygame.K_DOWN]:
        player.move(0, 1)

    tiles_group.draw(screen)
    player_group.draw(screen)
    pygame.display.flip()
    clock.tick(50)

pygame.quit()